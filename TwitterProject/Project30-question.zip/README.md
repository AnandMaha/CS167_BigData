# Project D: Twitter data analysis 
# Group 30 

## Student information
* Full name: Justin Figueroa
* E-mail: jfigu042@ucr.edu
* UCR NetID: jfigu042
* Student ID: 862136079
* Task 1

* Full name: Anand Mahadevan
* E-mail: amaha018@ucr.edu
* UCR NetID: amaha018
* Student ID: 862132182
* Task 2

* Full name: Justin Do
* E-mail: jdo062@ucr.edu
* UCR NetID: jdo062
* Student ID: 862248675
* Task 3
