# Lab 4

## Student information
* Full name: Anand Mahadevan
* E-mail: amaha018@ucr.edu
* UCR NetID: amaha018
* Student ID: 862132182

## Answers

* (Q1) What do you think the line `job.setJarByClass(Filter.class);` does?
  - It sets Filter as the class the JAR file will be built upon.
* (Q2) What is the effect of the line `job.setNumReduceTasks(0);`?
  - It sets the number of reducers to 0.
* (Q3) Where does the `main` function run? (Driver node, Master node, or an executor node).
  - Driver node
* (Q4) How many lines do you see in the output?
  - 27,972 lines (Line 27,973 is an empty line)
* (Q5) How many files are produced in the output?
  - 4 files are produced.
* (Q6) Explain this number based on the input file size and default block size.
  - Input file size is 1 KB, and the default block size is 128 MB, there is no correlation. However, there being
    1 part-r-0000x file matches with the output of the map task.
* (Q7) How many files are produced in the output?
  - 2 files are produced.
* (Q8) Explain this number based on the input file size and default block size.
  - Input file size is 1 KB, and the default block size is 128 MB, there is no correlation. However, there being 1
    part-r-000x file matches with the output of the map task.
* (Q9) How many files are produced in the output directory and how many lines are there in each file?
  - There are 3 files; no lines in _SUCCESS and part-r-00001, and 4 lines in part-r-00000.
* (Q10) Explain these numbers based on the number of reducers and number of response codes in the input file.
  - Because there are 2 reducers, there are 2 part-r-0000x files. A _SUCCESS file will always be produced to indicate
    the end of the job completion. There are 4 lines in part-r-00000 because there are a total of 4 response codes in the .tsv file.
* (Q11) How many files are produced in the output directory and how many lines are there in each file?
  - There are 3 files; no lines in _SUCCESS, part-r-00001 has 2 lines, and part-r-00000 has 5 lines.
* (Q12) Explain these numbers based on the number of reducers and number of response codes in the input file.
  - Because there are 2 reducers, there are 2 part-r-0000x files. A _SUCCESS file will always be produced to indicate
    the end of the job completion. There are 5 lines in part-r-00000 and 2 lines in part-r-00001 because there are a total of 7 response codes
    in the .tsv file.
* (Q13) How many files are produced in the output directory and how many lines are there in each file?
  - There are 3 files; no lines in _SUCCESS and part-r-00001, and 1 line in part-r-00000.
* (Q14) Explain these numbers based on the number of reducers and number of response codes in the input file.
  - Because there are 2 reducers, there are 2 part-r-0000x files. A _SUCCESS file will always be produced to indicate
    the end of the job completion. There is 1 line in part-r-00000 because there is a total of 1 response code
    in the .tsv file because it has been filtered for records of code 200 already.