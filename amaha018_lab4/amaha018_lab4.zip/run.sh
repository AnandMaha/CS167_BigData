#!/usr/bin/env sh
mvn clean package
yarn jar target/amaha018_lab4-1.0-SNAPSHOT.jar file://`pwd`/nasa_19950801.tsv file://`pwd`/filter_output 200
yarn jar target/amaha018_lab4-1.0-SNAPSHOT.jar file://`pwd`/filter_output file://`pwd`/aggregation_output